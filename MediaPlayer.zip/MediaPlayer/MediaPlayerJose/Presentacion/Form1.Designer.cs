﻿namespace MediaPlayerJose
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.archivoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.abrirCarpetaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ListaReproduccion = new System.Windows.Forms.ListBox();
            this.nombreArchivo = new System.Windows.Forms.Label();
            this.etiquetaDuracion = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.VetanaReproductor = new AxWMPLib.AxWindowsMediaPlayer();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.nombreListaReproduccion = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.agregarVideoAListaReproduccion = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button3 = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.VetanaReproductor)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.archivoToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // archivoToolStripMenuItem
            // 
            this.archivoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.abrirCarpetaToolStripMenuItem});
            this.archivoToolStripMenuItem.Name = "archivoToolStripMenuItem";
            this.archivoToolStripMenuItem.Size = new System.Drawing.Size(60, 20);
            this.archivoToolStripMenuItem.Text = "Archivo";
            // 
            // abrirCarpetaToolStripMenuItem
            // 
            this.abrirCarpetaToolStripMenuItem.Name = "abrirCarpetaToolStripMenuItem";
            this.abrirCarpetaToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.abrirCarpetaToolStripMenuItem.Text = "Abrir carpeta";
            this.abrirCarpetaToolStripMenuItem.Click += new System.EventHandler(this.AbrirCarpetaEvento);
            // 
            // ListaReproduccion
            // 
            this.ListaReproduccion.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            this.ListaReproduccion.FormattingEnabled = true;
            this.ListaReproduccion.Location = new System.Drawing.Point(462, 27);
            this.ListaReproduccion.Name = "ListaReproduccion";
            this.ListaReproduccion.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.ListaReproduccion.Size = new System.Drawing.Size(133, 394);
            this.ListaReproduccion.TabIndex = 2;
            this.ListaReproduccion.SelectedIndexChanged += new System.EventHandler(this.ListaReproduccionCambiadaEvento);
            // 
            // nombreArchivo
            // 
            this.nombreArchivo.AutoSize = true;
            this.nombreArchivo.BackColor = System.Drawing.Color.White;
            this.nombreArchivo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nombreArchivo.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.nombreArchivo.Location = new System.Drawing.Point(212, 6);
            this.nombreArchivo.Name = "nombreArchivo";
            this.nombreArchivo.Size = new System.Drawing.Size(80, 13);
            this.nombreArchivo.TabIndex = 3;
            this.nombreArchivo.Text = "NombreArchivo";
            this.nombreArchivo.Click += new System.EventHandler(this.label1_Click);
            // 
            // etiquetaDuracion
            // 
            this.etiquetaDuracion.AutoSize = true;
            this.etiquetaDuracion.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.etiquetaDuracion.Location = new System.Drawing.Point(496, 428);
            this.etiquetaDuracion.Name = "etiquetaDuracion";
            this.etiquetaDuracion.Size = new System.Drawing.Size(59, 13);
            this.etiquetaDuracion.TabIndex = 4;
            this.etiquetaDuracion.Text = "Duración 0";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.TemporizadorEvento);
            // 
            // VetanaReproductor
            // 
            this.VetanaReproductor.Enabled = true;
            this.VetanaReproductor.Location = new System.Drawing.Point(0, 27);
            this.VetanaReproductor.Name = "VetanaReproductor";
            this.VetanaReproductor.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("VetanaReproductor.OcxState")));
            this.VetanaReproductor.Size = new System.Drawing.Size(456, 423);
            this.VetanaReproductor.TabIndex = 1;
            this.VetanaReproductor.PlayStateChange += new AxWMPLib._WMPOCXEvents_PlayStateChangeEventHandler(this.PlayStateChangeEvento);
            this.VetanaReproductor.Enter += new System.EventHandler(this.VetanaReproductor_Enter);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(7)))), ((int)(((byte)(17)))));
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.nombreListaReproduccion);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.agregarVideoAListaReproduccion);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1.Location = new System.Drawing.Point(600, 24);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 426);
            this.panel1.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.Control;
            this.label1.Location = new System.Drawing.Point(60, 223);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(111, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Nombre nueva playlist";
            this.label1.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // nombreListaReproduccion
            // 
            this.nombreListaReproduccion.Location = new System.Drawing.Point(60, 196);
            this.nombreListaReproduccion.Name = "nombreListaReproduccion";
            this.nombreListaReproduccion.Size = new System.Drawing.Size(100, 20);
            this.nombreListaReproduccion.TabIndex = 3;
            this.nombreListaReproduccion.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // button2
            // 
            this.button2.Dock = System.Windows.Forms.DockStyle.Top;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button2.Location = new System.Drawing.Point(0, 145);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(200, 45);
            this.button2.TabIndex = 2;
            this.button2.Text = "Crear Lista De Reproducciones";
            this.button2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.UseVisualStyleBackColor = true;
            // 
            // agregarVideoAListaReproduccion
            // 
            this.agregarVideoAListaReproduccion.Dock = System.Windows.Forms.DockStyle.Top;
            this.agregarVideoAListaReproduccion.FlatAppearance.BorderSize = 0;
            this.agregarVideoAListaReproduccion.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.agregarVideoAListaReproduccion.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.agregarVideoAListaReproduccion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.agregarVideoAListaReproduccion.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.agregarVideoAListaReproduccion.Location = new System.Drawing.Point(0, 100);
            this.agregarVideoAListaReproduccion.Name = "agregarVideoAListaReproduccion";
            this.agregarVideoAListaReproduccion.Size = new System.Drawing.Size(200, 45);
            this.agregarVideoAListaReproduccion.TabIndex = 1;
            this.agregarVideoAListaReproduccion.Text = "Agregar Lista De Reproducciones";
            this.agregarVideoAListaReproduccion.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.agregarVideoAListaReproduccion.UseVisualStyleBackColor = true;
            this.agregarVideoAListaReproduccion.Click += new System.EventHandler(this.AgregarVideoAListaReproduccionEvento);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(200, 100);
            this.panel2.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(45, 24);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Red;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(762, 0);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(38, 24);
            this.button3.TabIndex = 8;
            this.button3.Text = "X";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.etiquetaDuracion);
            this.Controls.Add(this.nombreArchivo);
            this.Controls.Add(this.ListaReproduccion);
            this.Controls.Add(this.VetanaReproductor);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Reproductor";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.VetanaReproductor)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem archivoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem abrirCarpetaToolStripMenuItem;
        private AxWMPLib.AxWindowsMediaPlayer VetanaReproductor;
        private System.Windows.Forms.ListBox ListaReproduccion;
        private System.Windows.Forms.Label nombreArchivo;
        private System.Windows.Forms.Label etiquetaDuracion;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button agregarVideoAListaReproduccion;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox nombreListaReproduccion;
        private System.Windows.Forms.Label label1;
    }
}

