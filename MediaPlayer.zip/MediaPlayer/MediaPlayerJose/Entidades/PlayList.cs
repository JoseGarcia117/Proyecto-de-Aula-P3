﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MediaPlayerJose.Entidades
{
    public class PlayList
    {
        public int PlayList_id { get; set; }
        public string PlayList_nombre { get; set; }
        public string PlayList_descripcion { get; set; }

        public PlayList(int id, string nombre, string descripcion)
        {
            PlayList_id = id;
            PlayList_nombre = nombre;
            PlayList_descripcion = descripcion;
        }
    }
}

