﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MediaPlayerJose.Entidades
{
    public class Video
    {
        public int Video_id { get; set; }
        public string Video_titulo { get; set; }
        public string Video_ruta { get; set; }

        public Video(int id, string titulo, string ruta)
        {
            Video_id = id;
            Video_titulo = titulo;
            Video_ruta = ruta;
        }
    }
}
