﻿using MediaPlayerJose.Entidades;
using Oracle.ManagedDataAccess.Client; // Correct namespace for ODP.NET
using System;
using System.Configuration;

namespace MediaPlayerJose
{
    public class DatabaseHelper
    {
        // Oracle connection string
        private string connectionString = ConfigurationManager.ConnectionStrings["conexion"].ConnectionString;

        // Method to insert a new video into the database
        public void InsertVideo(Video video)
        {
            using (OracleConnection connection = new OracleConnection(connectionString))
            {
                connection.Open();

                OracleCommand command = new OracleCommand("InsertarVideos", connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.Add("p_titulo", OracleDbType.Varchar2).Value = video.Video_titulo;
                command.Parameters.Add("p_ruta", OracleDbType.Varchar2).Value = video.Video_ruta;
                command.ExecuteNonQuery();

                connection.Close();
            }
        }

        // Method to insert a new playlist into the database
        public void InsertPlayList(PlayList playlist)
        {
            using (OracleConnection connection = new OracleConnection(connectionString))
            {
                connection.Open();

                string query = "INSERT INTO Playlists (name, description) VALUES (p_nombre, p_descripcion) ";
                OracleCommand command = new OracleCommand(query, connection);
                command.Parameters.Add(new OracleParameter("p_nombre", playlist.PlayList_nombre));
                command.Parameters.Add(new OracleParameter("p_descripcion", playlist.PlayList_descripcion));
                command.ExecuteNonQuery();

                connection.Close();
            }
        }

        // Method to associate a video with a playlist
        public void AddVideoToPlaylist(int videoId, int playlistId)
        {
            using (OracleConnection connection = new OracleConnection(connectionString))
            {
                connection.Open();

                string query = "INSERT INTO PlaylistVideos (PlayList_id, Video_id) VALUES (p_playlistId, p_videoId)";
                OracleCommand command = new OracleCommand(query, connection);
                command.Parameters.Add(new OracleParameter("p_playlistId", playlistId));
                command.Parameters.Add(new OracleParameter("p_videoId", videoId));

                command.ExecuteNonQuery();

                connection.Close();
            }
        }
    }
}
