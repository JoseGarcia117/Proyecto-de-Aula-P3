﻿using MediaPlayerJose.Entidades;
using Oracle.ManagedDataAccess.Client; 
using Oracle.ManagedDataAccess.Types;
using System;
using System.Configuration;
using System.Windows.Forms;

namespace MediaPlayerJose
{
    public class DatabaseHelper
    {
        
        private string connectionString = ConfigurationManager.ConnectionStrings["conexion"].ConnectionString;

        
        public int InsertVideo(Video video)
        {
            using (OracleConnection connection = new OracleConnection(connectionString))
            {
                connection.Open();

                
                string query = "INSERT INTO Videos (TITLE, FILEPATH) VALUES (:title, :filepath) RETURNING VIDEOID INTO :videoId";
                OracleCommand command = new OracleCommand(query, connection);
                command.Parameters.Add(new OracleParameter(":title", video.Video_titulo));
                command.Parameters.Add(new OracleParameter(":filepath", video.Video_ruta));

    
                OracleParameter outputParam = new OracleParameter(":videoId", OracleDbType.Int32);
                outputParam.Direction = System.Data.ParameterDirection.Output;
                command.Parameters.Add(outputParam);

                command.ExecuteNonQuery();

                decimal videoId = outputParam.Value != DBNull.Value ? ((OracleDecimal)outputParam.Value).Value : 0m;
                return Convert.ToInt32(videoId);
            }
        }

        public int InsertPlayList(PlayList playlist)
        {
            using (OracleConnection connection = new OracleConnection(connectionString))
            {
                connection.Open();

                string query = "INSERT INTO Playlist (NAME, DESCRIPTION) VALUES (:name, :description) RETURNING PLAYLISTID INTO :playlistId";
                OracleCommand command = new OracleCommand(query, connection);
                command.Parameters.Add(new OracleParameter(":name", playlist.PlayList_nombre));
                command.Parameters.Add(new OracleParameter(":description", playlist.PlayList_descripcion));

                OracleParameter outputParam = new OracleParameter(":playlistId", OracleDbType.Int32);
                outputParam.Direction = System.Data.ParameterDirection.Output;
                command.Parameters.Add(outputParam);

                command.ExecuteNonQuery();

                decimal playlistId = outputParam.Value != DBNull.Value ? ((OracleDecimal)outputParam.Value).Value : 0m;
                return Convert.ToInt32(playlistId);
            }
        }

        
        public void AddVideoToPlaylist(int videoId, int playlistId)
        {
            using (OracleConnection connection = new OracleConnection(connectionString))
            {
                connection.Open();

                string query = "INSERT INTO MediaPlayer.PlaylistVideos (PLAYLISTID, VIDEOID) VALUES (:playlistId, :videoId)";
                OracleCommand command = new OracleCommand(query, connection);
                command.Parameters.Add(new OracleParameter(":playlistId", playlistId));
                command.Parameters.Add(new OracleParameter(":videoId", videoId));

                command.ExecuteNonQuery();
            }
        }

        public void LoadPlaylistsIntoComboBox(ComboBox comboBox)
        {
            using (OracleConnection connection = new OracleConnection(connectionString))
            {
                connection.Open();

                
                string query = "SELECT NAME FROM Playlist";
                OracleCommand command = new OracleCommand(query, connection);
                OracleDataReader reader = command.ExecuteReader();

               
                comboBox.Items.Clear();

                
                while (reader.Read())
                {
                    string playlistName = reader.GetString(0);  
                    comboBox.Items.Add(playlistName);
                }
 
                reader.Close();
            }
        }

        public void LoadVideosForSelectedPlaylist(ComboBox comboBox, ListBox listBox)
        {
            string selectedPlaylistName = comboBox.SelectedItem.ToString();

            using (OracleConnection connection = new OracleConnection(connectionString))
            {
                connection.Open();

                
                string query = @"
            SELECT v.TITLE
            FROM Videos v
            JOIN PlaylistVideos pv ON v.VIDEOID = pv.VIDEOID
            JOIN Playlist p ON pv.PLAYLISTID = p.PLAYLISTID
            WHERE p.NAME = :playlistName";

                OracleCommand command = new OracleCommand(query, connection);
                command.Parameters.Add(new OracleParameter(":playlistName", selectedPlaylistName));

                OracleDataReader reader = command.ExecuteReader();

                
                listBox.Items.Clear();

                
                while (reader.Read())
                {
                    string videoTitle = reader.GetString(0);  
                    listBox.Items.Add(videoTitle);
                }

                reader.Close();
            }
        }
    }
}
