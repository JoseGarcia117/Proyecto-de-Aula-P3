﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_aula.Entity
{
    internal class Category
    {
        private int Id_Category;
        private string Name_Category;

        public Category(int Id_Category, string Name_Category) 
        { 
        }
    }
}
