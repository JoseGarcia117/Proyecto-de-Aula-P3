﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_aula.Entity
{
    internal class Movie
    {
        private int Id_Movie;
        private String Title_Movie;
        private String Description_Movie;
        private Category Category;

        public Movie()
        { 
        }

    }
}
